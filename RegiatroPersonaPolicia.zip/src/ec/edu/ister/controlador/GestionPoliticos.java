/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.ister.controlador;

/**
 *
 * @author Carlos Carvajal y Luis Cevallos
 */
public class GestionPoliticos extends Conexion{
    public int registrarPolitico(){
        return 0;
    }
    public int buscarPolitico(){
        return 0;
    }
    public int modificarPolitico(){
        return 0;
    }
    public int EliminarPolitico(){
        return 0;
    }
}
