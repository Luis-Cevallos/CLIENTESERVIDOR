/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.ister.controlador;

import ec.edu.ister.vista.FrmGestionPoliticos;

/**
 *
 * @author Carlos Carvajal y Luis Cevallos
 */
public class ClaseMain {
    public static void main(String[] args) {
        FrmGestionPoliticos ventana = new FrmGestionPoliticos();
        ventana.setVisible(true);
    }
}
