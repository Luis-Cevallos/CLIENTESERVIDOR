/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ec.edu.ister.modelo;

/**
 *
 * @author Carlos Carvajal y Luis Cevallos
 */
public class Politico {
    private String idPol;
    private String cedulaPol;
    private String nombresPol;
    private String apellidosPos;
    private String telefonoPol;
    private String direccionPol;
    private String correoPol;
    private String tituloPol;
    private String partidoPol;


    /**
     * @return the tituloPol
     */
    public String getTituloPol() {
        return tituloPol;
    }

    /**
     * @param tituloPol the tituloPol to set
     */
    public void setTituloPol(String tituloPol) {
        this.tituloPol = tituloPol;
    }

    /**
     * @return the partidoPol
     */
    public String getPartidoPol() {
        return partidoPol;
    }

    /**
     * @param partidoPol the partidoPol to set
     */
    public void setPartidoPol(String partidoPol) {
        this.partidoPol = partidoPol;
    }
    
    /**
     * @return the idPol
     */
    public String getIdPol() {
        return idPol;
    }

    /**
     * @param idPol the idPol to set
     */
    public void setIdPol(String idPol) {
        this.idPol = idPol;
    }

    /**
     * @return the cedulaPol
     */
    public String getCedulaPol() {
        return cedulaPol;
    }

    /**
     * @param cedulaPol the cedulaPol to set
     */
    public void setCedulaPol(String cedulaPol) {
        this.cedulaPol = cedulaPol;
    }

    /**
     * @return the nombresPol
     */
    public String getNombresPol() {
        return nombresPol;
    }

    /**
     * @param nombresPol the nombresPol to set
     */
    public void setNombresPol(String nombresPol) {
        this.nombresPol = nombresPol;
    }

    /**
     * @return the apellidosPos
     */
    public String getApellidosPos() {
        return apellidosPos;
    }

    /**
     * @param apellidosPos the apellidosPos to set
     */
    public void setApellidosPos(String apellidosPos) {
        this.apellidosPos = apellidosPos;
    }

    /**
     * @return the telefonoPol
     */
    public String getTelefonoPol() {
        return telefonoPol;
    }

    /**
     * @param telefonoPol the telefonoPol to set
     */
    public void setTelefonoPol(String telefonoPol) {
        this.telefonoPol = telefonoPol;
    }

    /**
     * @return the direccionPol
     */
    public String getDireccionPol() {
        return direccionPol;
    }

    /**
     * @param direccionPol the direccionPol to set
     */
    public void setDireccionPol(String direccionPol) {
        this.direccionPol = direccionPol;
    }

    /**
     * @return the correoPol
     */
    public String getCorreoPol() {
        return correoPol;
    }

    /**
     * @param correoPol the correoPol to set
     */
    public void setCorreoPol(String correoPol) {
        this.correoPol = correoPol;
    }
}
